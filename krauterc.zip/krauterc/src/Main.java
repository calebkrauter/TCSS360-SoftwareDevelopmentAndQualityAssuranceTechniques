import java.math.BigDecimal;

import static java.lang.String.*;

public class Main {
    public static void main(String[] args) {
        new GenerateOutput();


    }
}